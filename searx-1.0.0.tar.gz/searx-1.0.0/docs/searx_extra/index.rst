.. _searx_extra:

======================================================
Tooling box ``searx_extra`` for developers and users
======================================================

In the folder :origin:`searx_extra/` we maintain some tools useful for
developers and users.

.. toctree::
   :maxdepth: 2
   :caption: Contents

   standalone_searx.py
